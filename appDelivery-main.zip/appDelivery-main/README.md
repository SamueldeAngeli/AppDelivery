# projetoDelivery
 Aplicativo feito no Android Studio em java, com a similaridade do iFood
